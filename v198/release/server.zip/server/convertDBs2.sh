./dbConvert2 biome.db 80000 8 12
./dbConvert2 eve.db 5000 50 12
./dbConvert2 floor.db 80000 8 4
./dbConvert2 floorTime.db 80000 8 8
./dbConvert2 lookTime.db 80000 8 8
./dbConvert2 mapTime.db 80000 16 8
./dbConvert2 map.db 80000 16 4
