./dbConvert biome.db 80000
./dbConvert eve.db 5000
./dbConvert floor.db 80000
./dbConvert floorTime.db 80000
./dbConvert lookTime.db 80000
./dbConvert mapTime.db 80000
./dbConvert map.db 80000