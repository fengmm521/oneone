./dbConvert3 biome.db 80000 8 12
./dbConvert3 eve.db 5000 50 12
./dbConvert3 floor.db 80000 8 4
./dbConvert3 floorTime.db 80000 8 8
./dbConvert3 lookTime.db 80000 8 8
./dbConvert3 mapTime.db 80000 16 8
./dbConvert3 map.db 80000 16 4
