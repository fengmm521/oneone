./dbCount biome.db 80000 8 12
./dbCount eve.db 5000 50 12
./dbCount floor.db 80000 8 4
./dbCount floorTime.db 80000 8 8
./dbCount lookTime.db 80000 8 8
./dbCount mapTime.db 80000 16 8
./dbCount map.db 80000 16 4